class MessageTypeNotFoundError(Exception):
    pass