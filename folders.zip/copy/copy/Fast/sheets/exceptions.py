class PathIsAFolderError(Exception):
    pass

class PathIsAFileError(Exception):
    pass

class NotFoundError(Exception):
    pass