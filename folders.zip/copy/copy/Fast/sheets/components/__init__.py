from .admin import AppAdmin
from .models import AppModels
from .settings import AppSettings
from .tests import AppTests
from .views import AppViews
from .forms import AppForms