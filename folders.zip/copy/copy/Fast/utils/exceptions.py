class TypeNotFoundError(Exception):
    pass


class EqualTypeError(Exception):
    pass


class DataCacheNotCreated(Exception):
    pass